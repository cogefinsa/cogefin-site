
# Site Cogefin — GitHub Pages (Optimisé)

Mise en ligne
1) Créez un dépôt public (ex. cogefin-site).
2) Uploadez tout le contenu de ce dossier (fichiers + sous-dossiers) dans la branche main.
3) Allez dans Settings → Pages → Source: Deploy from a branch → main /root → Save.
4) URL: https://<votre-user>.github.io/<repo>/

Options
- Domaine: ajoutez un fichier CNAME avec votre domaine.
- Formulaire: utilisez un service type Formspree ou Netlify.
